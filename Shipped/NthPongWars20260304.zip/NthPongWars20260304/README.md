# Nth Pong Wars - the README

![Old Nth Pong Wars Title Screen](https://www.agmsmith.ca/WeekendReports/20240207/20260116Main.gif)

Here's a quick guide in how to run _Nth Pong Wars_, on a real NABU PC from 1982
or on the [MAME](https://en.wikipedia.org/wiki/MAME) emulator.  I'm assuming
you found this README in some sort of a NthPongWars20260304.zip file, along
with the **Local Source** and **Store** folders.

There are two parts, a server side that emulates the old NABU cable TV data
network, and a client side (MAME or real hardware).

Also see the _Nth Pong Wars blog_ if you need details on how I install things:
[Blog on FreeNet](https://web.ncf.ca/au829/WeekendReports/20240207/NthPongWarsBlog.html)
[Blog on Alex's Server](http://www.agmsmith.ca/WeekendReports/20240207/NthPongWarsBlog.html)

## Server Side Setup

For the server side, I use the _NABU Internet Adapter_ from
[nabu.ca](https://nabu.ca/).  See instructions there for installing in Windows,
Linux or Macintosh.

Once it's working, find its data folder (Linux uses
~/Documents/NABU Internet Adapter) and copy the NthPongWars.nabu file in the
**Local Source** folder from the .zip file into the
**~/Documents/NABU Internet Adapter/Local Source/** folder.  Similarly, copy
the zip file's **NTHPONG** folder contents to the
**~/Documents/NABU Internet Adapter/Store/NTHPONG/** folder.

Then fire up the _NABU Internet Adapter_ and right at the bottom of the column listing all the programs you can run, there's a _Local Source_ section and it should have **NthPongWars** listed there.  Select it.

## Client Side Setup

For real NABUs, you need to connect their oddball serial cable to your server and fiddle with baud rates.

MAME needs some ROM images to run as a NABU.  Look for main system ROM nabupc-u53-90020060-reva-2732.bin and keyboard processor ROM nabukeyboard-90020070-reva-2716.bin and put them in the MAME roms directory, inside a nabupc directory.  Tell MAME to use that directory for ROMs, by starting MAME with no command line arguments and adding to the list of ROM folders it searches.

For MAME, you start it up (after first starting the server) with the command line:
```
mame nabupc -window -resolution 1024x768 -hcca null_modem -bitb socket.127.0.0.1:5716
```
You need to fiddle with baud rates too, in the Machine Configuration menu you
pop up just when the game starts by hitting tab.  Pick 115200 baud in both
directions, 8 bits, no parity, 2 stop bits, no flow control, and 4K BIOS.

Once you exit the config menu, or skip it by hitting a key or joystick button
or mouse, it should start up the NABU and then load the game.  You might be
able to play it then, but should change the MAME input settings so that the
keyboard doesn't pretend to be a joystick, the game has both one player
keyboard input (arrow keys and YES/F1 button) and four player joystick inputs.

There's also a version of MAME for the iPhone, called _Arcade Mania_, which
works though you have to make your server accessible over the network.  Or use
mine by changing the command line to *-bitb socket.www.agmsmith.ca:5716*

## Game Play

From the main screen, use the arrow keys or joystick to pick a direction.  You've got a tutorial, credits, _Classic Pong Wars_, quit, and if you hit fire/YES the main game.  Or do nothing and see a demo run (which you can join while it plays).

There are just two keys you can type, ESC brings you back to the main menu, and "q" quits.

You can also make your own levels, by editing the level files in the Store/NTHPONG folder.  E-mail me any good ones!

\- Alex

"Alexander G. M. Smith" <agmsmith@ncf.ca>  [www.agmsmith.ca](http://www.agmsmith.ca/)

March 2026

